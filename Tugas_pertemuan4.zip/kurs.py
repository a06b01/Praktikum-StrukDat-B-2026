EXCHANGE_RATES = {
    "USD": 15250,
    "EUR": 16600,
    "SGD": 11350,
    "JPY": 102,
    "MYR": 3215
}